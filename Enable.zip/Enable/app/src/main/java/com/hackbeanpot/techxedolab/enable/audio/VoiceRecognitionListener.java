package com.hackbeanpot.techxedolab.enable.audio;

import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;

public class VoiceRecognitionListener implements RecognitionListener {
    VoiceRecognition mVoiceRecognition;
    //private static final String TAG = "VoiceRecognitionListener";

    public VoiceRecognitionListener(VoiceRecognition instance) {
        mVoiceRecognition = instance;
    }

    public void onResults(Bundle data) {
        //Log.d(TAG, "onResults " + data);
        StringBuilder builder = new StringBuilder();
        ArrayList<String> matches = data.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        float[] value = data.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
        for (String match : matches) {
            builder.append(match + " ");
        }
        mVoiceRecognition.textView.setText("Results: " + "\n" + builder.toString());
    }

    public void onBeginningOfSpeech() {
        //Log.d(TAG, "onBeginningOfSpeech");
        mVoiceRecognition.textView.setText("Sounding good!");
    }

    public void onBufferReceived(byte[] buffer) {
        //Log.d(TAG, "onBufferReceived");
    }

    public void onEndOfSpeech() {
        //Log.d(TAG, "onEndofSpeech");
        mVoiceRecognition.textView.setText("Waiting for result...");
    }

    public void onError(int error) {
        //Log.d(TAG, "error " + error);
        if (error == 7)
            mVoiceRecognition.textView.setText("error " + "No match found.");
        else
            mVoiceRecognition.textView.setText("error " + error);
    }

    public void onEvent(int eventType, Bundle params) {
        //Log.d(TAG, "onEvent " + eventType);
    }

    public void onPartialResults(Bundle partialResults) {
        //Log.d(TAG, "onPartialResults");
    }

    public void onReadyForSpeech(Bundle params) {
        //Log.d(TAG, "onReadyForSpeech");
    }

    public void onRmsChanged(float rmsdB) {
        //Log.d(TAG, "onRmsChanged");
    }
}