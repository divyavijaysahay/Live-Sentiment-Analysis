package com.hackbeanpot.techxedolab.enable.audio;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.hackbeanpot.techxedolab.enable.R;

import java.util.ArrayList;

import static android.app.Activity.RESULT_OK;

public class VoiceRecognition extends Fragment {

    public SpeechRecognizer sr;
    public TextView textView;
    public static final String TAG = "VoiceRecognition";
    private StringBuilder builder;

    private static final int REQUEST_CODE = 1234;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        View view = inflater.inflate(R.layout.activity_voice_recognition, container, false);
        builder = new StringBuilder();
        initSpeechRecognizer();

        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        textView = getView().findViewById(R.id.text);

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        sr.startListening(intent);
        

    }

    /**
     * Handle the results from the voice recognition activity.
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            // Populate the wordsList with the String values the recognition engine thought it heard
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            float[] value = data.getFloatArrayExtra(RecognizerIntent.EXTRA_CONFIDENCE_SCORES);
            builder.append(String.valueOf(matches.size()));
            textView.setText(builder.append(" "));

            if(value != null) { // EXTRA_CONFIDENCE_SCORES wasn't added until API level 14
                String[] combined = new String[matches.size()];
                for(int i = 0; i < matches.size(); i++) // The size of the data and value is the same
                    combined[i] = matches.get(i).toString() + "\nScore: " + Float.toString(value[i]);
            }
        }
    }

    private void initSpeechRecognizer() {
        if(sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(getActivity().getApplicationContext());
            if (!SpeechRecognizer.isRecognitionAvailable((getActivity().getApplicationContext()))) {
                Toast.makeText(getActivity().getApplicationContext(),"Speech Recognition is not available",Toast.LENGTH_LONG).show();
            }
            sr.setRecognitionListener(new VoiceRecognitionListener(this));
        }

    }
    @Override
    public void onResume() {
        super.onResume();
        initSpeechRecognizer();
    }

    @Override
    public void onDestroy() {
        if (sr != null) {
            sr.stopListening();
            sr.cancel();
            sr.destroy();
        }
        super.onDestroy();
    }
}
